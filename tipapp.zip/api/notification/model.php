<?php

class Notification extends NotificationController {

    // Public properties
    public $id;
    public $ide;
    public $name;
    public $username;
    public $mobile;
    public $email;
    public $password;
    public $avatar;
    public $gender;
    public $lang;
    public $birthday;
    public $country;
    public $ip;
    public $token;
    public $fcm;
    public $code;
    public $isAdmin;
    public $isDeleted;
    public $status;
    public $createdAt;
    public $updatedAt;
    public $updatedBy;
    public $lastSeen;

    // Constructor to create a new user object
    public function __construct() {

        return $this;
    }

    // Set user data based on token
    public function set($row) {
        if (isset($row)) {
            $this->id = $row['id'];
            $this->ide = $this->encryptID($row['id']);
            $this->name = $row['name'];
            $this->username = $row['username'];
        } else {
            $this->reset();
        }

        return $this->getPublic() ; 
    }

    // Reset user data
    private function reset() {
        $this->id = null;
        $this->ide = null;
        $this->name = null;
        $this->username = null;
    }

    // Get public user data
    public function getPublic() {
        return [
            'id' => $this->ide,
            'name' => $this->name,
            'username' => $this->username
        ];
    }

    // Get full user data
    public function get() {
        return [
            'id' => $this->id,
            'ide' => $this->ide,
            'name' => $this->name,
            'username' => $this->username
        ];
    }

}



?>

<?php

class NotificationController {
    public function __construct() {

        return $this;
    }

  
    // coins receive
    public function sendWhatsAppCoinsReceived($toWhatsapp, $amount , $customer) {
        $whatsAppToken = canary::ENV('WHATSAPP_TOKEN');
        $sender = canary::ENV('WHATSAPP_SENDER');
        $templateName = "coins_received";
        $languageCode = canary::getLang() == 1 ? "en" : "ar"; // كود اللغة بناءً على لغة المستخدم
    
        $data = [
            "messaging_product" => "whatsapp",
            "recipient_type" => "individual",
            "to" => $toWhatsapp,
            "type" => "template",
            "template" => [
                "name" => $templateName,
                "language" => ["code" => $languageCode],
                "components" => [
                    [
                        "type" => "header",
                        "parameters" => [["type" => "text", "text" => $amount]]
                    ],
                    [
                        "type" => "body",
                        "parameters" => [["type" => "text", "text" => $amount] , ["type" => "text", "text" => $customer]]
                    ]
                ]
            ]
        ];
    
        $jsonData = json_encode($data);
    
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://graph.facebook.com/v16.0/'.$sender.'/messages',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $jsonData,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$whatsAppToken,
                'Content-Type: application/json'
            ),
        ));
    
        $response = curl_exec($curl);
        curl_close($curl);
        
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];
    
        $response = json_decode($response);
        // print_r($response);
        // echo"\n\n\n\n\n\n\n\n";
        // print_r($response->messages[0]->message_status) ;
        


        if( isset( $responseJson->messages[0]->message_status ) )
            {
                canary::listening("WHATSAPP_CNR[$cline] sent notification to client with response.");
                return true ;
            
            }
        else
            {
                canary::listeninge("WHATSAPP_CNR[$cline] sent notification to client with response.");
                return false ;
            }
    }

    public function sendSMS($receiver, $amount , $sender){

    }
    // send Notifications
    public function sendToReceiver($receiver , $amount , $sender ){

        if (canary::SELECT1("users WHERE `mobile` = '$receiver' OR `username` = '$receiver' OR `email` = '$receiver' "))
        {
            $row = canary::lastSQL();

            if( $row['fcm'] != '0' )
            {

                $deviceToken =  $row['fcm'] ;
                $fsnameSender = explode(' ', trim( $sender ));
                $senderName = $fsnameSender[0].' '.$fsnameSender[1];
                $name =  $row['name'] ;
                $receiverName = explode(' ', trim( $name ))[0];
                $forTest = 'cjgn3pkWRsOmq5MfQfIg-B:APA91bHUZVpO-o8uX8jnCouRfNLP3P3atc-V8-x1Dsk6H1xdz4TkmpkxHpFLDlympZ-fZ9vih02RSfNXr9qay-2jd9ozJWgbAR0Q9zKoGeAQ9oOlxvbfNnKKnsHWuDcJ1SooXbCYv9Lq';
                $deviceToken =  $forTest; 
                $image= 'https://tip.ebznz.com/assets/tip-gift.png';
                if( canary::getLang() == 1  )
                {
                    $title = "Welcome $receiverName";
                    $body = "You get amount $amount from $senderName .";
                }
                else{
                    $title = "مرحبا $receiverName";
                    $body = "لقد تلقيت مبلغ $amount من $senderName .";

                }


                 if( canary::sendFCM($deviceToken, $title , $body , $image))
                 {
                    return ;
                 }
            }

        }


        $forTest = 201557151288 ; // $receiver
        if($this->sendWhatsAppCoinsReceived($forTest, $amount , $sender))
        return ;


        $this->sendSMS($receiver, $amount , $sender) ;
        return ; 

        


    }

    public function sendToSender($sender , $amount , $type ){
        

    }



}

?>

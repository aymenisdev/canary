<?php

class Wallet extends Wallet_Controller {

    // Public properties
    public $id;
    public $ide;
    public $account;
    public $type;
    public $amount;
    public $share;
    public $fee;
    public $total;
    public $balance;
    public $currency;
    public $payment;
    public $client;
    public $comment;
    public $note;
    public $title;
    public $description;
    public $descriptionAr;
    public $status;
    public $payment_trx_id;
    public $createdAt;
    public $updatedAt;
    public $updatedBy;
  
    // Constructor to create a new user object
    public function __construct() {

        return $this;
    }

    // Set user data based on token
    public function set($id) {
       
        $row = canary::SELECT1(" `transactions` WHERE `id` = $id ");
        $type = $row['type'];
        $rowType = canary::SELECT1(" `transactions_type` WHERE `id` = $type ");

        if (isset($row)) {
            $this->id = $row['id'];
            $this->ide = $this->encryptID($row['id']);
            $this->account = $row['account'];
            $this->type = $row['type'];
            $this->amount = $row['amount'];
            $this->share = $row['share'];
            $this->fee = $row['fee'];
            $this->total = strval( $row['fee'] + $row['share'] + $row['amount'] );
            $this->currency = $row['currency'];
            $this->payment = $row['payment'];
            $this->client = $row['client'];
            $this->comment = $row['comment'];
            $this->note = $row['note'];
            $this->title = $rowType['title'];
            $this->description = $rowType['description'];
            $this->descriptionAr = $rowType['descriptionAr'];
            $this->status = $row['status'];
            $this->payment_trx_id = $row['payment_trx_id'];
            $this->createdAt = $row['createdAt'];
            $this->updatedAt = $row['updatedAt'];
            $this->updatedBy = $row['updatedBy'];
        } else {
            $this->reset();
        }

        return $this->getPublic() ; 
    }

    public function setBalance($balance) {
        $this->balance = $balance ; 
        return  $this->balance ;
    }

    // Reset user data
    private function reset() {
        $this->id = null ;
        $this->ide = null ;
        $this->account = null ;
        $this->type = null ;
        $this->amount = null ;
        $this->share = null ;
        $this->fee = null ;
        $this->total = null ;
        $this->balance = null ;
        $this->currency = null ;
        $this->payment = null ;
        $this->client = null ;
        $this->comment = null ;
        $this->note = null ;
        $this->title = null;
        $this->description = null;
        $this->descriptionAr = null;
        $this->status = null ;
        $this->payment_trx_id = null ;
        $this->createdAt = null ;
        $this->updatedAt = null ;
        $this->updatedBy = null ;
    }

    // Get full user data
    public function get() {
        return [
            'id' => $this->id ,
            'ide' => $this->ide ,
            'account' => $this->account ,
            'type' => $this->type ,
            'amount' => $this->amount ,
            'share' => $this->share ,
            'fee' => $this->fee ,
            'total' => $this->total ,
            'balance' => $this->balance ,
            'currency' => $this->currency ,
            'payment' => $this->payment ,
            'client' => $this->client ,
            'comment' => $this->comment ,
            'note' => $this->note ,
            'title' => $this->title ,
            'description' => $this->description ,
            'descriptionAr' => $this->descriptionAr ,
            'status' => $this->status ,
            'payment_trx_id' => $this->payment_trx_id ,
            'createdAt' => $this->createdAt ,
            'updatedAt' => $this->updatedAt ,
            'updatedBy' => $this->updatedBy ,
        ];
    }

    public function getPublic() {
        return [
            'id' => $this->ide ,
            'account' => $this->account ,
            'type' => $this->type ,
            'amount' => $this->amount ,
            'share' => $this->share ,
            'fee' => $this->fee ,
            'total' => $this->total ,
            'balance' => $this->balance ,
            'currency' => $this->currency ,
            'payment' => $this->payment ,
            'client' => $this->client ,
            'comment' => $this->comment ,
            'title' => $this->title ,
            'description' => $this->description ,
            'descriptionAr' => $this->descriptionAr ,
            'status' => $this->status ,
            'createdAt' => $this->createdAt ,
        ];
    }

}



?>

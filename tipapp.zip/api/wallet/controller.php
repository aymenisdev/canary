<?php

class Wallet_Controller {
    public function __construct() {

        return $this;
    }

    public function DoSomething() {
        chapter('wallet::DoSomething()');
       
    }

    public function deposit($user) {
        chapter('wallet->deposit');
        $request = canary::Request(); // amount , payment , paymentTrxId
        canary::validate( $request->paymentTrxId ,'num');
        canary::validate( $request->amount ,'num');
        canary::validate( $request->payment ,'num');
        $paymentTrxId = $request->paymentTrxId;
        $amount = $request->amount;
        $payment = $request->payment; 

        if( isset($request->comment) )
        {
            canary::validate( $request->comment , 'string' );
            $comment = $request->comment ; 
        }
        else
        $comment = '0';

        $this->checkPaymentTrxId($request->paymentTrxId);

        $currency = $this->getCurrency($user->country) ;
        $username = $user->username ;
        $fee = $this->calculateFees();
        $share = $this->calculateShare();

        canary::INSERT(" `transactions` SET `account`=$username,`type`=1, `amount`=$amount , `share`=$share, `fee`=$fee , `currency`= '$currency', `payment`= $payment , `payment_trx_id` = '$paymentTrxId' , `comment` = '$comment'");
        $lastId = canary::lastId();
        $this->setBalance($this->getPrivateBalance($username));
        $row = $this->set($lastId);
        canary::export('The transaction was completed successfully.',200 ,$row , 'تمت المعاملة بنجاح');
       
    }

    public function withdrawal($user) {
        chapter('wallet->withdrawal');
    
        $request = canary::Request(); // amount, payment
        canary::validate($request->amount, 'num');
        canary::validate($request->payment, 'num');
        $amount = $request->amount;
        $payment = $request->payment;
    
        if (isset($request->comment)) {
            canary::validate($request->comment, 'string');
            $comment = $request->comment;
        } else {
            $comment = '0';
        }
    
        $currency = $this->getCurrency($user->country);
        $username = $user->username;
        $fee = $this->calculateFees();
        $share = $this->calculateShare();
        $total = $amount + $fee + $share;
    
        // تحقق من الرصيد
        $currentBalance = $this->getPrivateBalance($username);
        if ($currentBalance < $total) {
            canary::export('Insufficient balance.', 400, null, 'الرصيد غير كافي');
     
        }
    
        canary::INSERT(" `transactions` SET `account`=$username, `type`=-1, `amount`=$amount, `share`=$share, `fee`=$fee, `currency`='$currency', `payment`=$payment, `comment`='$comment'");
        $lastId = canary::lastId();
        $this->setBalance($this->getPrivateBalance($username));
        $row = $this->set($lastId);
        canary::export('The transaction was completed successfully.', 200, $row, 'تمت المعاملة بنجاح');
    }
    
    public function transfer($array) {
        chapter('wallet->transfer');

        $user = $array[0];
        $noti = $array[1];
    
        $request = canary::Request(); // amount, payment, client, comment
        canary::validate($request->amount, 'num');
        canary::validate($request->payment, 'num');
        canary::validate($request->client, 'string'); // التحقق من العميل
        $amount = $request->amount;
        $payment = $request->payment;
        $client = $request->client;
    
        if (isset($request->comment)) {
            canary::validate($request->comment, 'string');
            $comment = $request->comment;
        } else {
            $comment = '0';
        }
    
        $currency = $this->getCurrency($user->country);
        $username = $user->username;
        $name = $user->name;
        $fee = $this->calculateFees();
        $share = $this->calculateShare();
        $total = $amount + $fee + $share;
    
        // تحقق من الرصيد
        $currentBalance = $this->getPrivateBalance($username);
        if ($currentBalance < $total) {
            canary::export('Insufficient balance.', 404, $currentBalance, 'الرصيد غير كافي');
        }
    
        // إدراج سجل التحويل للمرسل
        canary::INSERT(" `transactions` SET `account`=$username, `type`=-3, `amount`=$amount, `share`=$share, `fee`=$fee, `currency`='$currency', `payment`=$payment, `client`='$client', `comment`='$comment'");
        $lastId = canary::lastId();
    
        // إدراج سجل التحويل للمستقبل
        canary::INSERT(" `transactions` SET `account`='$client', `type`=3, `amount`=$amount, `share`=$share, `fee`=$fee, `currency`='$currency', `payment`=$payment, `client`='$username', `comment`='$comment'");
    

        $this->setBalance($this->getPrivateBalance($username));
        $row = $this->set($lastId);

        $currencyWithAmount = $currency.' '.$amount;
        $noti->sendToReceiver($client , $currencyWithAmount , $name );
        // $noti->sendToSender($client , $currencyWithAmount , $name );
    
        canary::export('The transaction was completed successfully.', 200,$row, 'تمت المعاملة بنجاح');
    }

    public function getStatement($id){
        canary::validate( $id ,'num');
        $rows = canary::SQL(" SELECT 
            t.id, 
        SUM(CASE 
            WHEN t.type > 0 THEN t.amount 
            ELSE -t.amount 
        END) 
        OVER (PARTITION BY t.account ORDER BY t.createdAt) AS 'balance'
        FROM 
        transactions t
        JOIN 
        transactions_type tt ON t.type = tt.id
        WHERE 
        t.account = $id
        AND tt.status = 1
        AND t.status = 1
        ORDER BY 
        t.createdAt DESC ");

        $i = 0 ; 
            foreach ($rows as $row) {

                $this->setBalance($row['balance']);
                $res[$i] = $this->set($row['id']);
    
                $i++;
  
            }     
                canary::export('The transaction was completed successfully.', 200,$res, 'تمت المعاملة بنجاح');
        
    }


    
    
        // Encrypt ID
    
    
    
    public function encryptID($id = null) {
        $encCode = 10001989;
        if (empty($id)) {
            $id = $this->id;
        }

        $biscID = str_replace("trx-", "", $id);
        if ($biscID == $id) {
            $id += $encCode;
            $biscID = 'trx-' . $id;
        } else {
            $biscID -= $encCode;
        }
        return $biscID;
    }





    // Private Function 
    function checkPaymentTrxId($id){

        if($id != 9564892351)
        canary::export('Transaction failed, please try again.',400 ,null , 'فشلت المعاملة الرجاء المحاولة مرة اخرى');

    }

    function calculateFees(){
        $request = canary::Request();
        canary::validate( $request->amount ,'num');
        return $request->amount * 0.029 ;
    }

    function calculateShare(){
        $request = canary::Request();

        canary::validate( $request->amount ,'num');

        if( isset( $request->withdrawal ) )
        return $request->amount * 0.05 ;
        else
        return 0 ;
    }

    function getCurrency($iso3){
        canary::validate( $iso3 ,'string');
        $row = canary::SELECT1(" `country` WHERE `ISO3` = '$iso3' ");
        return $row['currency'] ; 
    
    }

    public function getBalance($user){

 
        canary::validate( $user->username ,'num');
        $id =  $user->username ; 
        $iso3  =  $user->country ; 
        $row = canary::SQL("SELECT SUM(CASE WHEN `type` > 0 THEN `amount` ELSE -`amount` END) AS `balance` FROM `transactions` WHERE `account` = $id AND `status`=1 ");
        
        $row[0]['currency'] = $this->getCurrency($iso3) ;
        $row[0]['createdAt'] = date("Y-m-d H:i:s");
        canary::export('The transaction was completed successfully.', 200,$row[0], 'تمت المعاملة بنجاح');

    
    }

    function getPrivateBalance($id){
        canary::validate( $id ,'num');
        $row = canary::SQL("SELECT SUM(CASE WHEN `type` > 0 THEN `amount` ELSE -`amount` END) AS `balance` FROM `transactions` WHERE `account` = $id AND `status`=1 ");
        return $row[0]['balance'];
    }


}
    

?>

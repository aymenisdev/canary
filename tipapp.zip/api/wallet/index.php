<?php
require '../canary/setup.php';
canary::allowedDoctor();
// canary::allowedReport();
import('header-e'); // header , header-e , header-post , header-post-e
import('db');
import('token');// token , tokena for any type
importModel('User' , 'Notification' , 'ffghfghfhf');
$request = canary::Request(); // ::GET() , ::POST() , ::REQUEST() for all Method // print_r($data); // echo $data->canary ;
canary::Maintenance();
canary::Version(1,3,'1.0.2');
canary::checkToken('users' , 'token' );

$token = canary::getToken();


$user = new User();
$user->set($token);
$wallet = new Wallet();
$notification = new Notification();


// $user->coinsReceived(201557151288 , 950 , 'معز معتصم الحسيني');
// $deviceTokenFortest = 'cjgn3pkWRsOmq5MfQfIg-B:APA91bHUZVpO-o8uX8jnCouRfNLP3P3atc-V8-x1Dsk6H1xdz4TkmpkxHpFLDlympZ-fZ9vih02RSfNXr9qay-2jd9ozJWgbAR0Q9zKoGeAQ9oOlxvbfNnKKnsHWuDcJ1SooXbCYv9Lq';
// canary::sendFCM($deviceTokenFortest, 'مرحبا أيمن', 'لقد تلقيت مبلغ 250 قطعة نقدية من أسماء حسن جابر' , $image);

canary::Route('getBalance' , $wallet , $user );
canary::Route('getStatement' , $wallet , $user->username);
canary::Route('deposit' , $wallet , $user);
canary::Route('transfer' , $wallet , [$user , $notification]);
canary::Route('withdrawal' , $wallet , $user);

?>
<?php
require '../canary/setup.php';
import('header-e'); // header , header-e , header-post , header-post-e
import('db');
import('token');// token , tokena for any type
importModel('ModelName' , 'ModelName2' , 'ModelName3');
$request = canary::Request(); // ::GET() , ::POST() , ::REQUEST() for all Method // print_r($data); // echo $data->canary ;
canary::checkToken('users' , 'token' );
canary::Maintenance(0);
canary::Version(1,3,'1.0.2');

$user = new User();

canary::Route('signup' , $user , $request);
canary::Route('signin' , $user  );
canary::Route('update' , $user );
?>
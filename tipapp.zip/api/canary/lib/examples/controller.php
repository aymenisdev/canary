<?php

class ClassName_Controller {
    public function __construct() {

        return $this;
    }

    public function DoSomething() {
        chapter('DoSomething');
       
    }

}

?>

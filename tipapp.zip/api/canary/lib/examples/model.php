<?php

class ClassName extends ClassName_Controller {

    // Public properties
    public $id;
    public $name;
    public $email;
    public $password;
  
    // Constructor to create a new user object
    public function __construct() {

        return $this;
    }

    // Set user data based on token
    public function set($row) {
       

        if (isset($row)) {
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->email = $row['email'];
            $this->password = $row['password'];
        } else {
            $this->reset();
        }
    }

    // Reset user data
    private function reset() {
        $this->id = null;
        $this->name = null;
        $this->email = null;
        $this->password = null;
    }

    // Get public user data
    public function getPublic() {
        return [
            'name' => $this->name,
            'email' => $this->email,
        ];
    }

    // Get full user data
    public function get() {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'password' => $this->password,
        ];
    }

}



?>

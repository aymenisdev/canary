<?php
// Composer Packages
require __DIR__.'/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

// Global variables
$canary = array();
$importList = array();
$importListCount = 0;
$canary['allowedReport'] = 0;
$canary['report'] = '';
$canary['doctor'] = 0;
$canary['doctori'] = 0;
$canary['lang'] = 1;
$canary['lastSQL'] = null;
$canary['lastId'] = null;
$canary['mail'] =  new PHPMailer(true);

$http_status_codes = array(100 => "Continue", 101 => "Switching Protocols", 102 => "Processing", 200 => "OK", 201 => "Created", 202 => "Accepted", 203 => "Non-Authoritative Information", 204 => "No Content", 205 => "Reset Content", 206 => "Partial Content", 207 => "Multi-Status", 300 => "Multiple Choices", 301 => "Moved Permanently", 302 => "Found", 303 => "See Other", 304 => "Not Modified", 305 => "Use Proxy", 306 => "(Unused)", 307 => "Temporary Redirect", 308 => "Permanent Redirect", 400 => "Bad Request", 401 => "Unauthorized", 402 => "Payment Required", 403 => "Forbidden", 404 => "Not Found", 405 => "Method Not Allowed", 406 => "Not Acceptable", 407 => "Proxy Authentication Required", 408 => "Request Timeout", 409 => "Conflict", 410 => "Gone", 411 => "Length Required", 412 => "Precondition Failed", 413 => "Request Entity Too Large", 414 => "Request-URI Too Long", 415 => "Unsupported Media Type", 416 => "Requested Range Not Satisfiable", 417 => "Expectation Failed", 418 => "I'm a teapot", 419 => "Authentication Timeout", 420 => "Enhance Your Calm", 422 => "Unprocessable Entity", 423 => "Locked", 424 => "Failed Dependency", 424 => "Method Failure", 425 => "Unordered Collection", 426 => "Upgrade Required", 428 => "Precondition Required", 429 => "Too Many Requests", 431 => "Request Header Fields Too Large", 444 => "No Response", 449 => "Retry With", 450 => "Blocked by Windows Parental Controls", 451 => "Unavailable For Legal Reasons", 494 => "Request Header Too Large", 495 => "Cert Error", 496 => "No Cert", 497 => "HTTP to HTTPS", 499 => "Client Closed Request", 500 => "Internal Server Error", 501 => "Not Implemented", 502 => "Bad Gateway", 503 => "Service Unavailable", 504 => "Gateway Timeout", 505 => "HTTP Version Not Supported", 506 => "Variant Also Negotiates", 507 => "Insufficient Storage", 508 => "Loop Detected", 509 => "Bandwidth Limit Exceeded", 510 => "Not Extended", 511 => "Network Authentication Required", 598 => "Network read timeout error", 599 => "Network connect timeout error");
$http_status_codesAr =array(100 => "متابعة",101 => "تبديل البروتوكولات",102 => "جاري المعالجة",200 => "حسنًا",201 => "تم الإنشاء",202 => "مقبول",203 => "معلومات غير موثوقة",204 => "لا يوجد محتوى",205 => "إعادة ضبط المحتوى",206 => "محتوى جزئي",207 => "متعدد الحالات",300 => "خيارات متعددة",301 => "تم النقل نهائيًا",302 => "تم العثور عليه",303 => "انظر أخرى",304 => "لم يتم تعديله",305 => "استخدم الوكيل",306 => "(غير مستخدم)",307 => "إعادة توجيه مؤقتة",308 => "إعادة توجيه دائمة",400 => "طلب سيء",401 => "غير مصرح به",402 => "الدفع مطلوب",403 => "ممنوع",404 => "لم يتم العثور عليه",405 => "الأسلوب غير مسموح به",406 => "غير مقبول",407 => "مصادقة الوكيل مطلوبة",408 => "مهلة الطلب",409 => "الصراع",410 => "ذهب",411 => "الطول مطلوب",412 => "فشل الشرط المسبق",413 => "طلب الكيان كبير جدًا",414 => "معرف URI للطلب طويل جدًا",415 => "نوع الوسائط غير مدعوم",416 => "النطاق المطلوب غير مرضي",417 => "فشل التوقع",418 => "أنا إبريق شاي",419 => "مهلة المصادقة",420 => "عزز هدوءك",422 => "كيان غير قابل للمعالجة",423 => "مقفل",424 => "التبعية الفاشلة",424 => "فشل الأسلوب",425 => "مجموعة غير مرتبة",426 => "الترقية مطلوبة",428 => "الشرط المسبق مطلوب",429 => "الطلبات كثيرة جدًا",431 => "حقول رأس الطلب كبيرة جدًا",444 => "لا يوجد رد",449 => "إعادة المحاولة باستخدام",450 => "تم الحظر بواسطة المراقبة الأبوية لـ Windows",451 => "غير متاح لأسباب قانونية",494 => "رأس الطلب كبير جدًا",495 => "خطأ في الشهادة",496 => "لا توجد شهادة",497 => "HTTP إلى HTTPS",499 => "طلب العميل مغلق",500 => "خطأ داخلي في الخادم",501 => "لم يتم التنفيذ",502 => "البوابة سيئة",503 => "الخدمة غير متاحة",504 => "مهلة البوابة",505 => "إصدار HTTP غير مدعوم",506 => "المتغير يتفاوض أيضًا",507 => "مساحة التخزين غير كافية",508 => "تم اكتشاف حلقة",509 => "تم تجاوز حد النطاق الترددي",510 => "غير ممتد",511 => "يلزم مصادقة الشبكة",598 => "خطأ في مهلة قراءة الشبكة",599 => "خطأ في انتهاء مهلة الاتصال بالشبكة");



// Check language
if (isset(canary::REQUESTW()->ar))
    $canary['lang'] = 2;



function allowedReport(){
    $GLOBALS['canary']['allowedReport'] = 1 ;

}


// Check if Doctor get Doctor report
function allowedDoctor(){
    if (isset(canary::REQUESTW()->doctor))
    canary::doctor();

    if (isset(canary::REQUESTW()->doctori))
    canary::doctori();

}



// Function to import libraries
function import($lib) {
    $lib = strval($lib);
    require "../canary/lib/" . $lib . ".php";
    $GLOBALS['importList'][$GLOBALS['importListCount']] = $lib;
    $GLOBALS['importListCount']++;
}

// Function to import multiple models
function importModel(...$models) {
    try {
        foreach ($models as $mdl) {
            $mdl = strval($mdl);
            $mdlfile = "../" . $mdl . "/model.php";
            $ctrlfile = "../" . $mdl . "/controller.php";
            if (file_exists($mdlfile) && file_exists($ctrlfile) ) {
                
                require $ctrlfile;
                require $mdlfile;
                

                canary::listening("ImportModel '$mdl' successful.");
            } else {
                canary::listeninge("ImportModel '$mdl' failed.");
            }
        }
    } catch (Exception $e) {
        canary::listeninge("ImportModel failed.", $e->getMessage());
    }
}

// Function to print data
function cout($data) {
    if ($GLOBALS['canary']['doctor'] == 0) {
        try {
            if (isset($data) && $data != null) {
                $bt = debug_backtrace();
                $caller = array_shift($bt);
                print("\ncout[" . $caller['line'] . "] >> \n");
                print_r($data);
            } else {
                $bt = debug_backtrace();
                $caller = array_shift($bt);
                print("\ncout[" . $caller['line'] . "] >> \n");
                echo "null";
            }
        } catch (Exception $e) {
            $bt = debug_backtrace();
            $caller = array_shift($bt);
            print("\ncout[" . $caller['line'] . "] >> \n");
            echo "error";
        }
    }
}

// Function to print JSON data
function coutn($data) {
    if ($GLOBALS['canary']['doctor'] == 0) {
        try {
            if (isset($data) && $data != null) {
                print_r(json_encode($data));
            } else {
                $bt = debug_backtrace();
                $caller = array_shift($bt);
                print("\ncout[" . $caller['line'] . "] >> \n");
                echo "null";
            }
        } catch (Exception $e) {
            $bt = debug_backtrace();
            $caller = array_shift($bt);
            print("\ncout[" . $caller['line'] . "] >> \n");
            echo "error";
        }
    }
}

// Function to print a chapter header
function chapter($data = null) {
    if ($GLOBALS['canary']['doctor'] == 1) {
        try {
            if (isset($data) && $data != null) {
                $bt = debug_backtrace();
                $caller = array_shift($bt);
                print("\n\n--------------- $data -------------------------------  [" . $caller['line'] . "]\n\n");
            } else {
                $bt = debug_backtrace();
                $caller = array_shift($bt);
                print("\n\n--------------- chapter -------------------------------  [" . $caller['line'] . "]\n\n");
            }
        } catch (Exception $e) {
            $bt = debug_backtrace();
            $caller = array_shift($bt);
            print("\n\n--------------- chapter -------------------------------  [" . $caller['line'] . "]\n\n");
        }
    }
}

// Function to export JSON response
function export($jsonMsg, $code = null, $data = null, $jsonMsgAr = null) 
{

    if ($GLOBALS['canary']['lang'] == 2 && isset($jsonMsgAr))
    $jsonMsg = $jsonMsgAr;

if (!isset($code))
    $code = 400;

if ($GLOBALS['canary']['lang'] == 2 && isset($jsonMsgAr))
    $jsonMsgDef = $GLOBALS['http_status_codesAr'][$code];
else
    $jsonMsgDef = $GLOBALS['http_status_codes'][$code];



    
    if( $GLOBALS['canary']['allowedReport'] == 1)
    {
if (!isset($data))
    $json = [
        'status' => $code,
        'message' => $jsonMsg,
        'canary-report' =>  $GLOBALS['canary']['report']
    ];
else
    $json = [
        'status' => $code,
        'message' => $jsonMsg,
        'data' => $data,
        'canary-report' =>  $GLOBALS['canary']['report']
    ];
}
else
{
    if (!isset($data))
        $json = [
            'status' => $code,
            'message' => $jsonMsg,
        ];
    else
        $json = [
            'status' => $code,
            'message' => $jsonMsg,
            'data' => $data,
        ];
    }

header("HTTP/1.0 $code " . $jsonMsgDef);
echo json_encode($json);
// echo json_decode(json_encode($json['canary-report']));


exit(0);
}


function sendFirebaseNotification($deviceToken, $title, $body , $image = null)
{

    $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];



    $serviceAccountPath = $_ENV['FIREBASE_SERVICE_ACCOUNT_PATH'];
    $factory = (new Factory)->withServiceAccount($serviceAccountPath);
    $messaging = $factory->createMessaging();

    $message = CloudMessage::withTarget('token', $deviceToken)
        ->withNotification([
            'title' => $title,
            'body' => $body,
            'image'=> $image
        ]);

    try {

        $result = $messaging->send($message);
        canary::listening("FCM[$cline] send Notification success.", $result);
        // return ['success' => true, 'message_id' => $result];
        return true ;

    } catch (\Kreait\Firebase\Exception\MessagingException $e) {
        canary::listeninge("FCM[$cline] send Notification failed.", $e->getMessage());
        // return ['success' => false, 'error' => $e->getMessage()];
        return false ;
    } catch (\Kreait\Firebase\Exception\FirebaseException $e) {
        canary::listeninge("FCM[$cline] send Notification failed.", $e->getMessage());
        // return ['success' => false, 'error' => $e->getMessage()];
        return false ;        
    }
}

// Configuration class
class config {
    public static function db($server = null, $db, $user, $password = null) {
        try {
            $conn = new PDO("mysql:host=$server;dbname=$db", $user, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $myfile = fopen("../canary/lib/db.php", "w") or die("Unable to open file!");
            $txt = "<?php\ndate_default_timezone_set('Africa/Cairo');\n";
            fwrite($myfile, $txt);
            $txt = "\$server = '" . $server . "';\n";
            fwrite($myfile, $txt);
            $txt = "\$db = '" . $db . "';\n";
            fwrite($myfile, $txt);
            $txt = "\$user = '" . $user . "';\n";
            fwrite($myfile, $txt);
            $txt = "\$password = '" . $password . "';\n";
            fwrite($myfile, $txt);

            $txt = '
try {
    // Creating a new PDO connection
    $conn = new PDO("mysql:host=$server;dbname=$db", $user, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $GLOBALS["canary"]["conn"] = $conn;
    canary::listening("Database connection is successful.");

    $required_file = "model.php";
    if (file_exists($required_file)) {
        require $required_file;
        canary::listening("API Model file imported successful.");
    } else {
        canary::listeninge("API Model file not found.");
    }
} catch (PDOException $e) {
    canary::listeninge("Database connection failed.", $e->getMessage());
    export("Connection failed", 500, null, "فشل الاتصال");
}
?>';
            fwrite($myfile, $txt);
            fclose($myfile);

            canary::listening("Database library configuration successful.\n", $db);
        } catch (PDOException $e) {
            canary::listeninge("Database configuration failed.\n", '0');
            $jsonMsg = "Configuration failed ";
            $json = [
                "status" => 401,
                "message" => $jsonMsg,
            ];
            header("HTTP/1.0 401 " . $jsonMsg);
            echo json_encode($json);
            exit(0);
        }
    }
}

?>

<?php
$headers = getallheaders();
if (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
    list($type, $token) = explode(" ", $authHeader, 2);
    if ($type === 'Bearer') {
        if (isset($token) && !empty($token) && $token != 0) {
            $token = htmlspecialchars($token);
            $GLOBALS['canary']['token'] = $token;
            canary::listening("Token received successfully.", $token);
        } else {
            $GLOBALS['canary']['token'] = null ;
            canary::listeninge("Invalid token.");
        }
    } else {
        $GLOBALS['canary']['token'] = null ;
        canary::listeninge("Invalid token type.");
    }
} else {
    $GLOBALS['canary']['token'] = null ;
canary::listeninge("Authorization header not found.");

}

?>

<?php


// Allow all origins
header("Access-Control-Allow-Origin: *");

// Set the content type to JSON
header("Content-Type: application/json");

// Allow only GET method
header("Access-Control-Allow-Methods:POST");

// Allow specific headers
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Request-With");


?>
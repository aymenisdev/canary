<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
// error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
// error_reporting(E_ALL);
// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);


// Allow all origins
header("Access-Control-Allow-Origin: *");

// Set the content type to JSON
header("Content-Type: application/json");

// Allow only GET method
header("Access-Control-Allow-Methods: GET , POST , PUT , DELETE");

// Allow specific headers
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Request-With");


?>
<?php


// [country] => Egypt
// [countryAr] => مصر
// [fullname] => the Arab Republic of Egypt
// [fullnameAr] => جمهورية مصر العربية
// [currency] => EGP
// [currencyName] => Pound
// [dialKey] => +20
// [tax] => 14
// [ISO3] => EGY
// [ISO2] => EG
// [UNI] => 818
// [UNDP] => EGY
// [FAOSTAT] => 59
// [GAUL] => 40765
// [lastUpdateAt] => 2021-09-01 16:00:53
// [ip] => 156.193.141.219
// [status] => 200
// [delay] => 0ms
// [city] => Giza
// [region] => Giza
// [regionCode] => GZ
// [regionName] => Giza
// [areaCode] => 
// [dmaCode] => 
// [countryCode] => EG
// [countryName] => Egypt
// [inEU] => 0
// [euVATrate] => 
// [continentCode] => AF
// [continentName] => Africa
// [lat] => 30.008
// [lng] => 31.2194
// [locationAccuracyRadius] => 5
// [timezone] => Africa/Cairo
// [currencyCode] => EGP
// [currencySymbol] => &#163;
// [currencySymbol_UTF8] => £
// [currencyConverter] => 49.3216
// [address] => Egypt, Giza



function geolocation($ip = null)
{
   

    if(empty($ip))
    {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
              $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
              $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    }


$res = file_get_contents('https://canary.ebznz.com/api/geo/?key=freeForCanaryKey&ip='.$ip);


return $res ;

    
}
?>
<?php
date_default_timezone_set(canary::ENV('DB_TIMEZONE'));

$server = canary::ENV('DB_HOST');
$db = canary::ENV('DB_NAME');
$user = canary::ENV('DB_USERNAME');
$password = canary::ENV('DB_PASSWORD');

try {
    // Creating a new PDO connection
    $conn = new PDO("mysql:host=$server;dbname=$db", $user, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $GLOBALS["canary"]["conn"] = $conn;
    canary::listening("Database connection is successful.");

    $required_file = "controller.php";
    if (file_exists($required_file)) {
        require $required_file;
        canary::listening("API Controller file imported successful.");
    } else {
        canary::listeninge("API Controller file not found.");
    }
    
    $required_file = "model.php";
    if (file_exists($required_file)) {
        require $required_file;
        canary::listening("API Model file imported successful.");
    } else {
        canary::listeninge("API Model file not found.");
    }


   

    
} catch (PDOException $e) {
    canary::listeninge("Database connection failed.", $e->getMessage());
    export("Connection failed", 500, null, "فشل الاتصال");
}
?>

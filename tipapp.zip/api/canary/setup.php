<?php



require 'lib/main.php';
use Dotenv\Dotenv;
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();


class CANARY
{
    public function __construct() {}

    public static function var($var) {
        return $GLOBALS[$var];
    }

    public static function SET($var, $val) {
        $GLOBALS['canary'][$var] = $val;
    }

    public static function GET() {
        $i = 0;
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if ($_GET) {
            foreach ($_GET as $key => $value) {
                $canaryVar = htmlspecialchars($key);
                $data[$canaryVar] = htmlspecialchars($value);
                $i++;
            }
        } else {
            $data['canary'] = [
                'status' => 'success',
                'message' => 'No data collected with GET method!',
                'count' => 0
            ];
        }

        if ($i != 0) {
            $data['canary'] = [
                'status' => 'success',
                'message' => 'Successfully collected data with GET method.',
                'count' => $i,
                'request-method' => $_SERVER['REQUEST_METHOD']
            ];
            self::listening("GET[$cline] is successful with $i Data.", json_encode($data));
        } else {
            $data['canary'] = [
                'status' => 'failed',
                'message' => 'Failed data collection with GET method.',
                'count' => $i,
                'request-method' => $_SERVER['REQUEST_METHOD']
            ];
            self::listeninge("GET[$cline] with no data", json_encode($data));
        }

        return json_decode(json_encode($data));
    }

    public static function POST() {
        $i = 0;
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if ($_POST) {
            foreach ($_POST as $key => $value) {
                $canaryVar = htmlspecialchars($key);
                $data[$canaryVar] = htmlspecialchars($value);
                $i++;
            }
        } else {
            $data['canary'] = [
                'status' => 'success',
                'message' => 'No data collected with POST method!',
                'count' => 0
            ];
        }

        if ($i != 0) {
            $data['canary'] = [
                'status' => 'success',
                'message' => 'Successfully collected data with POST method.',
                'count' => $i,
                'request-method' => $_SERVER['REQUEST_METHOD']
            ];
            self::listening("POST[$cline] is successful with $i Data.", json_encode($data));
        } else {
            $data['canary'] = [
                'status' => 'failed',
                'message' => 'Failed data collection with POST method.',
                'count' => $i,
                'request-method' => $_SERVER['REQUEST_METHOD']
            ];
            self::listeninge("POST[$cline] with no data", json_encode($data));
        }

        return json_decode(json_encode($data));
    }

    public static function REQUEST() {
        
        $i = 0;
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if ($_REQUEST) {
            foreach ($_REQUEST as $key => $value) {
                $canaryVar = htmlspecialchars($key);
                $data[$canaryVar] = htmlspecialchars($value);
                $i++;
            }
        } else {
            $data['canary'] = [
                'status' => 'success',
                'message' => 'No data collected with REQUEST method!',
                'count' => 0
            ];
        }

        if ($i != 0) {
            $data['canary'] = [
                'status' => 'success',
                'message' => 'Successfully collected all data with REQUEST method.',
                'count' => $i,
                'request-method' => $_SERVER['REQUEST_METHOD']
            ];
            self::listening("REQUEST[$cline] is successful with $i Data.", json_encode($data));
        } else {
            $data['canary'] = [
                'status' => 'failed',
                'message' => 'Failed data collection with REQUEST method.',
                'count' => $i,
                'request-method' => $_SERVER['REQUEST_METHOD']
            ];
            self::listeninge("REQUEST[$cline] with no data", json_encode($data));
        }

        return json_decode(json_encode($data));
    }

    public static function REQUESTW() {
        $i = 0;
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];
     

        if ($_REQUEST) {
            foreach ($_REQUEST as $key => $value) {
                $canaryVar = htmlspecialchars($key);
                $data[$canaryVar] = htmlspecialchars($value);
                $i++;
            }
        }

        

        return json_decode(json_encode($data));
    }

    public static function ENV( $var =  null ) {

        if( $var == null)
        return json_decode(json_encode($_ENV));
        else
        return json_decode(json_encode($_ENV[$var]));
    }

    public static function sendOTPEmail($toEmail , $otp) {

        
        $mail = canary::var('canary')['mail'] ;
        try {
            //Server settings
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = self::ENV('MAIL_HOST');                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = self::ENV('MAIL_USERNAME');                     //SMTP username
            $mail->Password   = self::ENV('MAIL_PASSWORD');                               //SMTP password
            $mail->SMTPSecure = self::ENV('MAIL_ENCRYPTION');// PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = self::ENV('MAIL_PORT');                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        
            //Recipients
            $mail->setFrom(self::ENV('MAIL_FROM_ADDRESS'), 'Canary Framework');  //$mail->setFrom(self::ENV('MAIL_HOST'), 'no-replay');
            $mail->addAddress($toEmail);     //Add a recipient
            // $mail->addAddress('ellen@example.com');               //Name is optional
            // $mail->addReplyTo('admin@ebznz.com', 'Information');
            $mail->addCC(self::ENV('MAIL_CC'));
            // $mail->addBCC('bcc@example.com');
        
            //Attachments
            // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
        
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Verification Code OTP';
            $mail->Body    = '<table border="0" cellpadding="0" cellspacing="0" width="100%">
              <tr><td align="left">
              <h2>One-Time Password (OTP)</h2>
              <p>Dear Canary Customer,</p>
              <p>Your OTP for verification is: <strong>'.$otp.'</strong></p>
              <p>Enter this code on the login page to complete the verification process.</p>
              <p>Best regards,</p>
              Canary Framework</td></tr></table>';
            $mail->AltBody = 'Your Verification Code for Canary Freamwork non-HTML mail clients';
        
            $mail->send();
            echo "\nEmail has been sent";
        } catch (Exception $e) {
            echo "\nEmail could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
        





    }


    public static function sendOTPWhatsApp($toWhatsapp, $otp) {
        $whatsAppToken = self::ENV('WHATSAPP_TOKEN');
        $sender = self::ENV('WHATSAPP_SENDER');
        $templateName = "verification_code";
        $languageCode = self::getLang() == 1 ? "en" : "ar"; // كود اللغة بناءً على لغة المستخدم
    
        $data = [
            "messaging_product" => "whatsapp",
            "recipient_type" => "individual",
            "to" => $toWhatsapp,
            "type" => "template",
            "template" => [
                "name" => $templateName,
                "language" => ["code" => $languageCode],
                "components" => [
                    [
                        "type" => "body",
                        "parameters" => [["type" => "text", "text" => $otp]]
                    ],
                    [
                        "type" => "button",
                        "sub_type" => "url",
                        "index" => "0",
                        "parameters" => [["type" => "text", "text" => $otp]]
                    ]
                ]
            ]
        ];
    
        $jsonData = json_encode($data);
    
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://graph.facebook.com/v16.0/'.$sender.'/messages',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $jsonData,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$whatsAppToken,
                'Content-Type: application/json'
            ),
        ));
    
        $response = curl_exec($curl);
        curl_close($curl);
        
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];
    
        $responseJson = json_decode($response);
       if( isset( $responseJson->messages[0]->message_status ) )
        self::listening("WHATSAPP_OTP[$cline] sent OTP with response.");
     else
        self::listeninge("WHATSAPP_OTP[$cline] sent OTP with response.");

    }

    public static function sendFCM($deviceToken, $title, $body , $image = null ){
    return sendFirebaseNotification($deviceToken, $title, $body , $image);
    }

    public static function getLang() {
        
            $res = self::var('canary')['lang'];
       

        return $res;
    }

    public static function getToken() {
        
        $res = self::var('canary')['token'];
   

    return $res;
}

    public static function checkToken($dbtbl, $dbtoken = null, $dbexpier = null) {
        if (self::checkLibImport('token') == 1 || self::checkLibImport('tokena') == 1) {
            $token = self::var('canary')['token'];

            
            // if( $token == 'new' || $token == 'signin' || $token == 'login' || empty($token) || !isset($token) || $token == 0 || $token = null || $token == '' || $token == '0' )
            // {

            //     $data = self::REQUESTW();
            //     if( (isset($data->password) || isset($data->pin) || isset($data->code)  ) && ( isset($data->username) || isset($data->user) || isset($data->mobile) || isset($data->email) )  )
            //     {
            //         $res = "User request new token successfully.";
            //         self::listening("User request new token successfully." , json_encode($data));

            //     } else {
            //         $res = "User request new token failed.";
            //         self::listeninge("User request new token failed.", '0');
                    
            //         export( 'User try to request new token failed' , 401 , null , "فشلت محاولة المستخدم لطلب رمز التأمين جديد");
            //     }
            // }
           

            if( $token != null )
            $res = self::SELECTW("`$dbtbl` WHERE `$dbtoken` =  '$token'");

            if (isset($res)) {
                self::listening("Token has been authenticated successfully.", $res);
            } else {
                self::listeninge("Token authentication failed.", '0');
                export( 'Invalid token' , 401 , null , "رمز التأمين غير صالح");
            }
        
        } else {
            $res = "🐤 Canary tweet:\nYou must import the token library\nimport('token'); // for Bearer Type\nor use\nimport('tokena'); // for Any Type";
        }

        return $res;
    }

    public static function VERSION( $minVersion ,  $lastVersion , $lastVersionName ) {

        if( empty( self::REQUESTW()->platform ) || self::REQUESTW()->platform == 'android' || self::REQUESTW()->platform == 'ios' )
        {
        if( self::REQUESTW()->version <  $minVersion )
        export("You must update to the latest version $lastVersionName .",426 ,null ,"يجب تحديث النسخة الأخيرة $lastVersionName ");
        }

    }

    public static function MAINTENANCE( $maintenance = null ) {

        if( $maintenance != null && $maintenance != 0 )
        export("There is $maintenance-minute maintenance",503 ,null ,"توجد صيانة لمدة $maintenance دقيقة ");
    }

    public static function allowedReport() {
        allowedReport();
    }

    public static function allowedDoctor() {
        allowedDoctor();
    }

    public static function doctor() {
        echo "🩺 Canary Doctor Report: ---------------------------- [0]\n";
        self::SET('doctor',1);
        self::SET('doctori',0);
        return self::var('canary')['doctor'];
    }

    public static function doctori() {
        echo "🩺 Canary Doctor-info Report: ---------------------------- [0]\n";
        self::SET('doctor',1);
        self::SET('doctori',1);
        return self::var('canary')['doctor'];
    }

    public static function listening($res, $data = null) {
        if (self::var('canary')['doctor'] == 1) {
            print_r("\n✔️ " . $res);
            if ($data != '0' && isset($data) && self::var('canary')['doctori'] == 1) {
                print_r("\n[" . $data . PHP_EOL . "]\n");
            }
        }

    //     if(isset($data))
    //     $GLOBALS['canary']['report']= $GLOBALS['canary']['report']."\n✔️ " . $res . "[$data]." ;
    // else
        $GLOBALS['canary']['report']= $GLOBALS['canary']['report']."\n✔️ " . $res;
    }

    public static function listeninge($res, $data = null) {
        if (self::var('canary')['doctor'] == 1) {
            print_r("\n⛔ " . $res);
            if ($data != '0' && isset($data) && self::var('canary')['doctori'] == 1) {
                print_r("\n[" . $data . PHP_EOL . "]\n");
            }
        }


        // if(isset($data))
        //  $GLOBALS['canary']['report']= $GLOBALS['canary']['report']."\n⛔ " . $res . "[$data]." ;
        // else
         $GLOBALS['canary']['report']= $GLOBALS['canary']['report']."\n⛔ " . $res;


    }

    public static function export($jsonMsg, $code = null, $data = null, $jsonMsgAr = null) {
       export($jsonMsg, $code, $data , $jsonMsgAr );
    }

    // SQL commands ...

    public static function conn() {
        return self::var('canary')['conn'];
    }

    public static function SQL($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                $rows = $stmt->rowCount();

                if ($rows > 0) {
                    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } else {
                    $row = null;
                }

                self::listening("SQL[$cline] is successful with $rows Rows.", $sql);
            } catch (PDOException $e) {
                self::listeninge("SELECT[$cline] query failed.", $e->getMessage());
                $row = null;
            }
        } else {
            self::listeninge("You must import the database library\nimport('db');\n", '0');
            $row = null;
        }

        self::SET('lastSQL', $row);
        return $row;
    }

    public static function SELECT($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("SELECT * FROM $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();

                if ($rows > 0) {
                    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } else {
                    $row = null;
                }

                self::listening("SELECT[$cline] is successful with $rows Rows.", $sql);
            } catch (PDOException $e) {
                self::listeninge("SELECT[$cline] query failed.", $e->getMessage());
                $row = null;
            }
        } else {
            self::listeninge("You must import the database library\nimport('db');\n", '0');
            $row = null;
        }

        self::SET('lastSQL', $row);
        return $row;
    }

    public static function SELECTW($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("SELECT * FROM $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();

                if ($rows > 0) {
                    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } else {
                    $row = null;
                }

                
            } catch (PDOException $e) {
                
                $row = null;
            }
        } else {
            
            $row = null;
        }

        // self::SET('lastSQL', $row);
        return $row;
    }

    public static function SELECT1($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("SELECT * FROM $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();

                if ($rows > 0) {
                    $row = $stmt->fetchAll(PDO::FETCH_ASSOC)[0];
                } else {
                    $row = null;
                }

                self::listening("SELECT[$cline] is successful with $rows Rows.", $sql);
            } catch (PDOException $e) {
                self::listeninge("SELECT[$cline] query failed.", $e->getMessage());
                $row = null;
            }
        } else {
            self::listeninge("You must import the database library\nimport('db');\n", '0');
            $row = null;
        }

        self::SET('lastSQL', $row);
        return $row;
    }

    public static function SELECT1W($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("SELECT * FROM $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();

                if ($rows > 0) {
                    $row = $stmt->fetchAll(PDO::FETCH_ASSOC)[0];
                } else {
                    $row = null;
                }

                
            } catch (PDOException $e) {
                
                $row = null;
            }
        } else {
            
            $row = null;
        }

        // self::SET('lastSQL', $row);
        return $row;
    }

    public static function INSERT($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("INSERT INTO $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();
                self::SET('lastId', $conn->lastInsertId());
                self::listening("INSERT[$cline] is successful.", $rows);
            } catch (PDOException $e) {
                self::listeninge("INSERT[$cline] SQL failed.", $e->getMessage());
                $row = null;
            }
        } else {
            self::listeninge("You must import the database library\nimport('db');\n", '0');
            $row = null;
        }

        return $row;
    }

    public static function UPDATE($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("UPDATE $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();
                self::SET('lastId', $conn->lastInsertId());
                self::listening("UPDATE[$cline] is successful.", $rows);
            } catch (PDOException $e) {
                self::listeninge("UPDATE[$cline] SQL failed.", $e->getMessage());
                $row = null;
            }
        } else {
            self::listeninge("You must import the database library\nimport('db');\n", '0');
            $row = null;
        }

        return $row;
    }

    public static function DELETE($sql) {
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];

        if (self::checkLibImport('db') == 1) {
            $conn = self::conn();

            try {
                $stmt = $conn->prepare("DELETE FROM $sql");
                $stmt->execute();
                $rows = $stmt->rowCount();
                self::SET('lastId', $conn->lastInsertId());
                self::listening("DELETE[$cline] is successful.", $rows);
            } catch (PDOException $e) {
                self::listeninge("DELETE[$cline] SQL failed.", $e->getMessage());
                $row = null;
            }
        } else {
            self::listeninge("You must import the database library\nimport('db');\n", '0');
            $row = null;
        }

        return $row;
    }

    public static function lastSQL() {
        return self::var('canary')['lastSQL'];
    }

    public static function lastId() {
        return self::var('canary')['lastId'];
    }


    //  Public Methods :

    public static function checkLibImport($lib) {
        $res = 0;
        foreach (self::var('importList') as $value) {
            if ($value == $lib) {
                $res = 1;
            }
        }

        return $res;
    }

    public static function geo($ip = null ) {
     
        

        if (self::checkLibImport('geo') == 1 ) {
            $res = json_decode( geolocation($ip));
        } else {
            $res = "🐤 Canary tweet:\nYou must import the geo library\nimport('geo'); ";
        }

        return $res;

    }

    public static function Route($key ,$class , $prm = null ){
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];

        // print_r($prms);
        // echo count($prms);

        try{
        
           
                foreach ($_REQUEST as $keyName => $value) {
                  
                  
                  if(htmlspecialchars($keyName) == $key)
                  {
                    // if( $prms )
                    // {
                    // foreach ($prms as $prm) {
                    return $class->$key($prm);
                    // }
                    // }
                    // else{
                        // return $class->$key();
                    // }
                  }

                   
                }

                self::listeninge("ROUTE[$cline] to $key method failed.");
           


     
        
        }
        catch (Exception $e) {
            self::listeninge("ROUTE[$cline] to method failed.", $e->getMessage());
            return null ;
        }

    }

    public static function VALIDATE(&$input, $type = null, $options = []) {
        try {
            // التحقق من عدم وجود البيانات
            if (empty($input)) {
                export("Data is incomplete", 400, null, "البيانات غير مكتملة");
                return; // الخروج من الدالة إذا كانت البيانات غير مكتملة
            }
    
            // إذا كان النوع خالٍ، لن يتم التحقق من النوع
            if ($type === null) {
                return; // الخروج من الدالة لأن التحقق من النوع غير مطلوب
            }
    
            // تنقية البيانات
            $input = htmlspecialchars($input);
    
            // التحقق من نوع البيانات بناءً على $type
            switch ($type) {
                case 'string':
                case 'text':
                    if (!is_string($input)) {
                        export("The data type is not text", 400, null, "نوع البيانات ليس حرفي");
                    }
                    if (isset($options['min']) && strlen($input) < $options['min']) {
                        export("Text is too short", 400, null, "النص قصير جدًا");
                    }
                    break;
    
                case 'money':
                case 'float':
                case 'double':
                    if (!is_double($input)) {
                        export("The data type is not double", 400, null, "نوع البيانات ليس رقم مفصل");
                    }
                    break;
    
                case 'bool':
                case 'true':
                case 'false':
                case 'boolean':
                    if (!is_bool($input)) {
                        export("The data type is not boolean", 400, null, "نوع البيانات ليس منطقي");
                    }
                    break;
    
                case 'array':
                case 'list':
                case 'map':
                    if (!is_array($input)) {
                        export("The data type is not array", 400, null, "نوع البيانات ليس مصفوفة");
                    }
                    break;
    
                case 'url':
                case 'link':
                case 'web':
                case 'uri':
                    if (!filter_var($input, FILTER_VALIDATE_URL)) {
                        export("The data type is not URL", 400, null, "نوع البيانات ليس رابط موقع");
                    }
                    break;
    
                case 'num':
                case 'number':
                    if (!is_numeric($input)) {
                        export("The data type is not number", 400, null, "نوع البيانات ليس رقمي");
                    }
                    break;

                case 'code':
                    if (!is_numeric($input) || $input == 0 ) {
                        export("The data type is not number", 400, null, "نوع البيانات ليس رقمي");
                    }
                    break;
    
                case 'mobile':
                case 'phone':
                case 'tel':
                    // التحقق من أن الرقم يمكن أن يبدأ بمفتاح دولي اختياري ويتبعه 9 إلى 11 رقمًا
                    if (!preg_match('/^\+?\d{1,4}?\d{9,11}$/', $input)) {
                        export("Invalid mobile number", 400, null, "رقم الموبايل غير صالح");
                    }
                    break;
    
                case 'email':
                case 'mail':
                case 'mailto':
                case 'e-mail':
                case 'e_mail':
                case 'emailaddress':
                case 'eaddress':
                    if (!filter_var($input, FILTER_VALIDATE_EMAIL)) {
                        export("Invalid Email", 400, null, "البريد الالكتروني غير صالح");
                    }
                    break;
    
                case 'fcm':
                case 'fcm_token':

                    if(! self::sendFCM($input , '' , ''))
                    export("Invalid FCM Key", 400, null, "مفتاح الجهاز غير صالح");
                    break;
                case 'ip':
                case 'ipaddress':
                case 'ip_address':
                case 'ip-address':
                    if (!filter_var($input, FILTER_VALIDATE_IP)) {
                        export("Invalid IP address", 400, null, "عنوان الأي بي غير صالح");
                    }
                    break;
    
                case 'password':
                case 'pass':
                case 'pwd':
                    if (strlen($input) < 8) {
                        export("Password must be at least 8 characters long", 400, null, "يجب أن تتكون كلمة المرور من 8 أحرف على الأقل");
                    }
                    break;
    
                case 'password-m':
                case 'pass-m':
                case 'pwd-m':
                    $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/';
                    if (!preg_match($pattern, $input)) {
                        export("Password must contain at least one uppercase letter, one lowercase letter, and one digit.", 400, null, "يجب أن تتكون كلمة المرور من 8 أحرف على الأقل، تحتوي على حرف كبير واحد على الأقل، حرف صغير واحد على الأقل، ورقم واحد.");
                    }
                    break;
    
                case 'password-s':
                case 'pass-s':
                case 'pwd-s':
                    $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/';
                    if (!preg_match($pattern, $input)) {
                        export("Password must contain at least one uppercase letter, one lowercase letter, one digit, and one symbol.", 400, null, "يجب أن تتكون كلمة المرور من 8 أحرف على الأقل، تحتوي على حرف كبير واحد على الأقل، حرف صغير واحد على الأقل، رقم واحد، ورمز واحد على الأقل.");
                    }
                    break;
    
                default:
                    export("Invalid type specified", 400, null, "نوع غير صالح محدد");
                    break;
            }
        } catch (Exception $e) {
            // التعامل مع أي استثناء قد يحدث
            export("An error occurred: " . $e->getMessage(), 500, null, "حدث خطأ: " . $e->getMessage());
        }
    }
    

    function DEF( ) {
        
        $i = 0;
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];
        $cclass = $caller['class'];

        // echo  $cfile ; 
        $className = strstr($cfile, "api\\"  );
        $className = ltrim($className, "api\\" );
        $className = rtrim($className, "\\model.php" );
        echo  $className."()" ;       
    }

    // Additional methods remain unchanged
}

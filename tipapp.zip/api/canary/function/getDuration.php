<?php




function getDuration($dsql , $tsql )
{
$d1=$dsql." ".$tsql;
$d2=date("Y-M-d H:i:s");
return SumDuration($d1 , $d2 );
}

function getDuration1($dtsql )
{
$d1=$dtsql;
$d2=date("Y-M-d H:i:s");
return SumDuration($d1 , $d2 );
}

function SumDuration($d1 , $d2 )
{
$lang = "ar";
$date1=strtotime($d1); //date("Y/M/d H:i:s");
$date2=strtotime($d2);

$diff = abs($date2 - $date1);

$years = floor($diff / (365*60*60*24));

$months = floor( ($diff - $years * 365*60*60*24) / (30*60*60*24)) ;

$days = floor( ($diff - $years * 365*60*60*24 - $months*30*60*60*24) / (60*60*24)) ;

  $hours = floor( ($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24) / (60*60)) ;

$minutes = floor( ($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 -$hours*60*60) / 60) ;


$yearsN = date("Y" , $date1); // d ,D , M , m 

if($lang == "en")
$monthsN = date("M" , $date1); 

if($lang == "ar")
$monthsN = date("m" , $date1); 

$daysN = date("d" , $date1);
$daysNn = date("D" , $date1); 




if($lang == "en")
{
$hourN=" h";
$minuteN=" m";
$nowN="Now";
}

if($lang == "ar")
{
if($monthsN == 1 )
$monthsN = "يناير";

if($monthsN == 2 )
$monthsN = "فبراير";

if($monthsN == 3 )
$monthsN = "مارس";

if($monthsN == 4 )
$monthsN = "أبريل";

if($monthsN == 5 )
$monthsN = "مايو";

if($monthsN == 6 )
$monthsN = "يونيو";

if($monthsN == 7 )
$monthsN = "يوليو";

if($monthsN == 8 )
$monthsN = "أغسطس";

if($monthsN == 9 )
$monthsN = "سبتمبر";

if($monthsN == 10 )
$monthsN = "أكتوبر";

if($monthsN == 11 )
$monthsN = "نوفمبر";

if($monthsN == 12 )
$monthsN = "ديسمبر";



if($daysNn == "Sat")
$daysNn = "السبت" ;

if($daysNn == "Sun")
$daysNn = "الأحد";

if($daysNn == "Mon")
$daysNn = "الإثنين";

if($daysNn == "Tue")
$daysNn = "الثلاثاء";

if($daysNn == "Wed")
$daysNn = "الأربعاء" ;

if($daysNn == "Thu")
$daysNn = "الخميس";

if($daysNn == "Fri")
$daysNn = "الجمعه";

$hourN=" س";
$minuteN=" د";
$nowN="الأن";
}



if($lang == "ar")
{
if($years == 0)
        if($months == 0)
        if($days == 0)
        if($hours == 0)
        if($minutes < 5)
        return $nowN;
        else
        return $minutes.$minuteN;
        else
        return $hours.$hourN;
        else if($days < 6)
        return $daysNn;
        else
        return $daysN." ".$monthsN;
        else
        return $daysN." ".$monthsN;
        else
        return $yearsN;
}

if($lang == "en")
{
if($years == 0)
        if($months == 0)
        if($days == 0)
        if($hours == 0)
        if($minutes < 5)
        return $nowN;
        else
        return $minutes." ".$minuteN;
        else
        return $hours." ".$hourN;
        else if($days < 6)
        return $daysNn;
        else
        return $daysN." ".$monthsN;
        else
        return $daysN." ".$monthsN;
        else
        return $yearsN;
}

        
}






?>
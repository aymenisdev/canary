<?php

class CANARY
{
    public function __construct() {}

    public static function var($var) {
        return $GLOBALS[$var];
    }

    public static function SET($var, $val) {
        $GLOBALS['canary'][$var] = $val;
    }

    public static function GET() {
        // التعريف هنا
    }

    public static function POST() {
        // التعريف هنا
    }

    public static function REQUEST() {
        // التعريف هنا
    }

    public static function ENV($var = null) {
        // التعريف هنا
    }

    public static function sendOTPEmail($toEmail, $otp) {
        // التعريف هنا
    }

    public static function sendOTPWhatsApp($toWhatsapp, $otp) {
        // التعريف هنا
    }

    public static function sendFCM($deviceToken, $title, $body, $image = null) {
        // التعريف هنا
    }

    public static function getLang() {
        // التعريف هنا
    }

    public static function getToken() {
        // التعريف هنا
    }

    public static function checkToken($dbtbl, $dbtoken = null, $dbexpier = null) {
        // التعريف هنا
    }

    public static function VERSION($minVersion, $lastVersion, $lastVersionName) {
        // التعريف هنا
    }

    public static function MAINTENANCE($maintenance = null) {
        // التعريف هنا
    }

    public static function allowedReport() {
        // التعريف هنا
    }

    public static function allowedDoctor() {
        // التعريف هنا
    }

    public static function doctor() {
        // التعريف هنا
    }

    public static function doctori() {
        // التعريف هنا
    }

    public static function listening($res, $data = null) {
        // التعريف هنا
    }

    public static function listeninge($res, $data = null) {
        // التعريف هنا
    }

    public static function export($jsonMsg, $code = null, $data = null, $jsonMsgAr = null) {
        // التعريف هنا
    }

    public static function SQL($sql) {
        // التعريف هنا
    }

    public static function SELECT($sql) {
        // التعريف هنا
    }

    public static function SELECTW($sql) {
        // التعريف هنا
    }

    public static function SELECT1($sql) {
        // التعريف هنا
    }

    public static function SELECT1W($sql) {
        // التعريف هنا
    }

    public static function INSERT($sql) {
        // التعريف هنا
    }

    public static function UPDATE($sql) {
        // التعريف هنا
    }

    public static function DELETE($sql) {
        // التعريف هنا
    }
}

![CanaryBg](https://github.com/user-attachments/assets/9b13ca27-a225-4ea8-9d13-855112b31b00)



# CANARY COMMANDs :
Canary Php Framework .


This PHP code defines a class CANARY that seems to serve as a utility class for handling HTTP requests, logging, token management, and database interactions. Here’s a brief breakdown of the class:

Constructor and Basic Methods:

__construct(): An empty constructor, possibly used as a placeholder.
var($var): Static method to return a global variable.
SET($var, $val): Sets a value in the global $canary array.
GET(), POST(), REQUEST(), REQUESTW(): Methods to handle HTTP GET, POST, and REQUEST variables, respectively. They process incoming data, sanitize it using htmlspecialchars, and log the result.
Token and Language Methods:

getToken(): Retrieves the token from the global canary array if the appropriate libraries are imported.
getLang(): Retrieves the language from the global canary array.
Token Verification and Maintenance:

checkToken($dbtbl, $dbtoken, $dbexpier): Checks the validity of a token and logs the result.
VERSION($minVersion, $lastVersion, $lastVersionName): Checks if the application version is up-to-date and prompts the user to update if necessary.
MAINTENANCE($maintenance): Provides a maintenance notice if maintenance is scheduled.
Diagnostics:

doctor() and doctori(): Methods for setting up diagnostic reports.
Logging Methods:

listening($res, $data): Logs successful operations.
listeninge($res, $data): Logs failed operations.
Database Interaction Methods:

Methods like conn(), SQL($sql), SELECT($sql), INSERT($sql), UPDATE($sql), and DELETE($sql) are used for various database operations using MySQLi.
Utility and Helper Methods:

lastSQL(), lastId(): Retrieve the last SQL query or ID.
checkLibImport($lib): Checks if a specific library is imported.
geo($ip): Attempts to perform a geolocation lookup.
Routing and Validation:

Route($key, $class, $parameters): Routes requests to specified class methods based on a key.
VALIDATE($prm, $type): Validates the data type of a parameter and throws an error if it doesn’t match the expected type.
Notes for Improvement:
Security:

Although htmlspecialchars is used for sanitizing user input, additional measures like parameterized queries for SQL operations are advisable to prevent SQL injection attacks.
The use of global variables is generally discouraged as it can lead to unexpected side effects and security issues.
Error Handling:

The code uses basic try-catch blocks, but the exception handling could be more robust with specific error messages and logging mechanisms.
Modularity:

Consider separating concerns into different classes or modules (e.g., a separate class for database operations, another for HTTP request handling).
Documentation:

Adding comments and PHPDoc annotations would be helpful for maintaining and understanding the code.
Use of Modern PHP Practices:

Use of namespaces, type declarations, and strict typing where possible could improve code readability and reliability.
The class provides a lot of functionality, but careful attention should be paid to security, error handling, and modern coding practices.



require '../canary/setup.php';
canary::doctor();
canary::allowedReport();
canary::allowedDoctor();
import('header-e'); // header , header-e , header-post , header-post-e
config::db("localhost","u318433058_AzizApp","u318433058_AzizApp","AZiz#Ff6ApP");
import('db');
import('token');// token , tokena for all type
import('geo');
importModel('request' , 'driver' , 'notification');

$request = canary::REQUEST(); // ::GET() , ::POST() , ::REQUEST() for all Method // print_r($data); // echo $data->canary ;

canary::checkToken('users' , 'token' );

chapter('user');

$user = new User();
cout($user->name);
cout($data->name);

coutn($user);

echo canary::getToken();

$rows = canary::SELECT('* FROM `country` WHERE `status`>0 ');
$rowss = canary::SELECT('* FROM `ccountry` WHERE `status`<-1 ');

echo $user->encryptID('5000')."\n\n\n";
echo $user->encryptID('user-1006989')."\n\n\n";
echo $user->encryptID();


$geov = canary::geo('156.193.141.219'); // $request->ip 
print_r($geov);
$country = $geov->ISO3;
// $country = $geov['ISO3'];
$fullMobile = $geov->key."". strval( intval( $mobile ));
print_r( canary::geo('156.193.141.219'));


chapter('Route');
canary::Route('signup' , new User() , $request);
canary::Route('signin' , new User() );
canary::Route('update' , new User() );



// VALIDATE data default check if its empty() email , pwd string money bool array url number mobile email ip (pwd pwd-m pwd-s) :

canary::VALIDATE($user);
canary::VALIDATE($password ,'pwd-s');
canary::VALIDATE($user , 'mobile');
canary::VALIDATE($password , 'pwd' );



canary::Maintenance(); // return status code  [503] Service Unavailable

canary::Version(1,1,'1.0.0'); // // return status code  [426] Upgrade Required

print_r( canary::ENV('API_KEY') );

canary::mail('aymenisdev@gmail.com' ,'68291');

canary::sendOTPWhatsApp(201557151288, 26841 );

$user->coinsReceived(201557151288 , 100 , 'شيماء الحسيني');

canary::sendFCM($deviceToken, $title, $body , $image);







# Vars :
__CLASS__
__DIR__	
__FILE__	
__FUNCTION__
__LINE__	
__METHOD__	
__NAMESPACE__	
__TRAIT__



# _SERVER Vars :
$_SERVER['PHP_SELF'];
$_SERVER['SCRIPT_NAME'];

$_SERVER['SERVER_NAME'];
$_SERVER['HTTP_HOST'];

$_SERVER['HTTP_REFERER'];
$_SERVER['HTTP_USER_AGENT'];





# http_status_codes :

100 => "Continue" .
101 => "Switching Protocols" .
102 => "Processing" .
200 => "OK" .
201 => "Created" .
202 => "Accepted" .
203 => "Non-Authoritative Information" .
204 => "No Content" .
205 => "Reset Content" .
206 => "Partial Content" .
207 => "Multi-Status" .
300 => "Multiple Choices" .
301 => "Moved Permanently" .
302 => "Found" .
303 => "See Other" .
304 => "Not Modified" .
305 => "Use Proxy" .
306 => "(Unused)" .
307 => "Temporary Redirect" .
308 => "Permanent Redirect" .
400 => "Bad Request" .
401 => "Unauthorized" .
402 => "Payment Required" .
403 => "Forbidden" .
404 => "Not Found" .
405 => "Method Not Allowed" .
406 => "Not Acceptable" .
407 => "Proxy Authentication Required" .
408 => "Request Timeout" .
409 => "Conflict" .
410 => "Gone" .
411 => "Length Required" .
412 => "Precondition Failed" .
413 => "Request Entity Too Large" .
414 => "Request-URI Too Long" .
415 => "Unsupported Media Type" .
416 => "Requested Range Not Satisfiable" .
417 => "Expectation Failed" .
418 => "I'm a teapot" .
419 => "Authentication Timeout" .
420 => "Enhance Your Calm" .
422 => "Unprocessable Entity" .
423 => "Locked" .
424 => "Failed Dependency" .
424 => "Method Failure" .
425 => "Unordered Collection" .
426 => "Upgrade Required" .
428 => "Precondition Required" .
429 => "Too Many Requests" .
431 => "Request Header Fields Too Large" .
444 => "No Response" .
449 => "Retry With" .
450 => "Blocked by Windows Parental Controls" .
451 => "Unavailable For Legal Reasons" .
494 => "Request Header Too Large" .
495 => "Cert Error" .
496 => "No Cert" .
497 => "HTTP to HTTPS" .
499 => "Client Closed Request" .
500 => "Internal Server Error" .
501 => "Not Implemented" .
502 => "Bad Gateway" .
503 => "Service Unavailable" .
504 => "Gateway Timeout" .
505 => "HTTP Version Not Supported" .
506 => "Variant Also Negotiates" .
507 => "Insufficient Storage" .
508 => "Loop Detected" .
509 => "Bandwidth Limit Exceeded" .
510 => "Not Extended" .
511 => "Network Authentication Required" .
598 => "Network read timeout error" .
599 => "Network connect timeout error" .




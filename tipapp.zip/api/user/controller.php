<?php

class UserController {
    public function __construct() {

        return $this;
    }

    // Sign in a user
    public function signin() {
        chapter('signin');
        $request = canary::Request();
        $token = canary::getToken();
        $user = $request->user;
        $password = $request->password;
        $fcm = $request->fcm;
        canary::VALIDATE($fcm);

        if (!empty($user) && !empty($password)) {
            canary::VALIDATE($user);
            canary::VALIDATE($password, 'pwd-m');

            if (canary::SELECT1("users WHERE `mobile` = '$user' OR `username` = '$user' OR `email` = '$user' ")) {
                $row = canary::lastSQL();
                if (password_verify($password, $row['password'])) {

                    $id = $row['id'];
                    $status = $row['status'];
                    $token = $row['token'];

                    if( $row['fcm'] != $fcm )
                    {
                        $new_token = $status == 0 ? $token : $this->generateNewToken();
                        $token = $new_token ;
                    }

                    canary::UPDATE("users SET `fcm`='$fcm' , `token`='$token' ,  `updatedBy` = $id  WHERE `id`=$id ");

                    $this->set($token);
                    $row = $this->getPublic();
                    canary::export("success", 200, $row, "تمت العملية بنجاح");
                } else {
                    canary::export("password incorrect", 400, null, "كلمة المرور غير صحيحة");
                }
            } else {
                canary::export("Invalid mobile number", 400, null, "رقم الجوال غير صحيح");
            }
        } elseif (!empty($token)) {
            if (canary::SELECT1("users WHERE `token` = '$token'")) {

                $row = canary::lastSQL();
                $id = $row['id'];
                $status = $row['status'];
                $token = $row['token'];

                if( $row['fcm'] != $fcm )
                {
                    $new_token = $status == 0 ? $token : $this->generateNewToken();
                    $token = $new_token ;
                }
                


                canary::UPDATE("users SET `fcm`='$fcm' , `token`='$token' ,  `updatedBy` = $id  WHERE `id`=$id ");
                $this->set($token);
                $row = $this->getPublic();
                canary::export("success", 200, $row, "تمت العملية بنجاح");
            } else {
                canary::export('Invalid token, You must signin again', 401, null, "يجب اعادة تسجيل الدخول");
            }
        } else {
            canary::export("Data is incomplete", 400, null, "البيانات غير مكتملة");
        }
    }

    // Verify user password (currently a stub)
    public function verifyOTPCode() {
        chapter('verifyOTPCode');
        $request = canary::Request();
        $token = canary::getToken();
        $code = $request->code ;

        canary::VALIDATE($code , 'code');

        if (canary::SELECT1("users WHERE `token` = '$token' AND ( `code` = $code OR `code`=0 )")) {

            $row = canary::lastSQL();
            $id = $row['id'];
            
            if( $row['code'] == 0 ||  $row['status'] == 1 )
            canary::export("Mobile number is already verified", 200, null, "تم توثيق رقم الجوال مسبقا");

            canary::UPDATE("users SET `status`=1 , `code`=0 , `updatedBy` = $id  WHERE `id`=$id AND `token` = '$token' AND `code` = $code ");
            canary::export("successs", 200, null, "تمت العملية بنجاح");
        } else {
            canary::export('Invalid verification code', 401, null, "كود التحقق غير صحيح");
        }



    }

    public function sendNewOTPCode() {
        chapter('sendNewOTPCode');
        $token = canary::getToken();

        if (canary::SELECT1("users WHERE `token` = '$token'")) {

            $row = canary::lastSQL();
            $id = $row['id'];
            $mobile = $row['username'];
            
            if( $row['code'] == 0 || $row['status'] == 1 )
            canary::export("Mobile number is already verified", 200, null, "تم توثيق رقم الجوال مسبقا");

            $code = rand(1000, 9999);
            $forTest1 = 201557151288 ;
            canary::sendOTPWhatsApp($forTest1, $code );
            
            canary::UPDATE("users SET  `code`=$code , `updatedBy` = $id  WHERE `id`=$id AND `token` = '$token'");
            canary::export("The code has been sent", 200, null, "تم ارسال الكود");
        } else {
            export( 'Invalid token' , 401 , null , "رمز التأمين غير صالح");
        }



    }

    public function sendPasswordCode() {
        chapter('sendPasswordCode');
        $request = canary::Request();
        $user = $request->user;
        canary::VALIDATE($user);

        if (canary::SELECT1("users WHERE `mobile` = '$user' OR `username` = '$user' OR `email` = '$user' ")) {
            $row = canary::lastSQL();
            $id = $row['id'];
            $mobile = $row['username'];
            
            $code = rand(1000, 9999);
            $forTest1 = 201557151288 ;
            canary::sendOTPWhatsApp($forTest1, $code );
            
            canary::UPDATE("users SET  `code`=$code , `updatedBy` = $id  WHERE `id`=$id");
            canary::export("The code has been sent", 200, null, "تم ارسال الكود");
        } else {
            canary::export("Invalid mobile number", 400, null, "رقم الجوال غير صحيح");
        }



    }

    public function restPassword() {
        chapter('restPassword');
        $request = canary::Request();
        canary::VALIDATE($request->code , 'code');
        canary::VALIDATE($request->user);
        canary::VALIDATE($request->password, 'pwd-m');
        $user = $request->user ;
        $code = $request->code ;
        $password = $request->password ;
        

        if (canary::SELECT1("users WHERE (`mobile` = '$user' OR `username` = '$user' OR `email` = '$user') AND `code` = $code ")) {
            $row = canary::lastSQL();
            $id = $row['id'];
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            canary::UPDATE("users SET  `code`=0 , `password` = '$hashed_password' , `updatedBy` = $id  WHERE `id`=$id AND `code` = $code ");
            canary::export("successs", 200, null, "تمت العملية بنجاح");
        } else {
            canary::export('Invalid verification code', 401, null, "كود التحقق غير صحيح");
        }



    }

    // Sign up a new user
    public function signup() {
        chapter('signup');

        $request = canary::Request();
        canary::VALIDATE($request->name, 'string');
        canary::VALIDATE($request->password, 'pwd-m');
        canary::VALIDATE($request->mobile, 'mobile');
        canary::VALIDATE($request->fcm );

        $mobile = $request->mobile;
        $lang = canary::getLang();
        $new_token = $this->generateNewToken();

        $forTest0 = '156.193.141.219' ; 
        $geov = canary::geo($forTest0);
        $ip = $geov->ip;
        $country = $geov->ISO3;
        $fullMobile = strval($geov->key) . strval(intval($mobile));

        if (!canary::SELECT1("users WHERE `mobile` = '$mobile' OR `username` = '$mobile' OR `token` = '$new_token' ")) {
            $hashed_password = password_hash($request->password, PASSWORD_DEFAULT);
            $code = rand(1000, 9999);

            canary::INSERT("`users` set `name` = '$request->name', 
            `username` = '$fullMobile', `mobile` = '$request->mobile', 
            `password` = '$hashed_password', `token` = '$new_token', 
            `fcm` = '$request->fcm', `ip` = '$ip', 
            `country` = '$country', `lang` = $lang, `code` = $code");

            $this->set($new_token);
            $row = $this->getPublic();

            $forTest1 = 201557151288 ;
            canary::sendOTPWhatsApp($forTest1, $code );
            canary::export("success", 200, $row, "تمت العملية بنجاح");
        } else {
            canary::listeninge("INSERT query failed Mobile already registered.");
            canary::export("Mobile Number already registered", 400, null, "رقم الموبايل مسجل بالفعل");
        }
    }

    // Update an existing user's password
    public function update() {
        chapter('update');
        $request = canary::Request();
        canary::export("Model Update incomplete", 400, null, "نموذج التعديل غير مكتمل");
    }

    // Encrypt ID
    public function encryptID($id = null) {
        $encCode = 1001989;
        if (empty($id)) {
            $id = $this->id;
        }

        $biscID = str_replace("user-", "", $id);
        if ($biscID == $id) {
            $id += $encCode;
            $biscID = 'user-' . $id;
        } else {
            $biscID -= $encCode;
        }
        return $biscID;
    }

    // Generate new token
    public function generateNewToken() {
        do {
            $new_token = bin2hex(random_bytes(16)); // generates a crypto-secure 32 characters long
        } while (canary::SELECT1("users WHERE `token` = '$new_token'"));

        return $new_token;
    }

    // Get all the existing users
    public function getUsers() {
        chapter('getUsers');

        $query = 'SELECT user, mobile , email FROM users';

        return $this->db->query($query);
    }
    
    // coins receive
    public function sendWhatsAppCoinsReceived($toWhatsapp, $amount , $customer) {
        $whatsAppToken = canary::ENV('WHATSAPP_TOKEN');
        $sender = canary::ENV('WHATSAPP_SENDER');
        $templateName = "coins_received";
        $languageCode = canary::getLang() == 1 ? "en" : "ar"; // كود اللغة بناءً على لغة المستخدم
    
        $data = [
            "messaging_product" => "whatsapp",
            "recipient_type" => "individual",
            "to" => $toWhatsapp,
            "type" => "template",
            "template" => [
                "name" => $templateName,
                "language" => ["code" => $languageCode],
                "components" => [
                    [
                        "type" => "header",
                        "parameters" => [["type" => "text", "text" => $amount]]
                    ],
                    [
                        "type" => "body",
                        "parameters" => [["type" => "text", "text" => $amount] , ["type" => "text", "text" => $customer]]
                    ]
                ]
            ]
        ];
    
        $jsonData = json_encode($data);
    
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://graph.facebook.com/v16.0/'.$sender.'/messages',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $jsonData,
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer '.$whatsAppToken,
                'Content-Type: application/json'
            ),
        ));
    
        $response = curl_exec($curl);
        curl_close($curl);
        
        $bt = debug_backtrace();
        $caller = array_shift($bt);
        $cline = $caller['line'];
        $cfile = $caller['file'];
    
        $response = json_decode($response);
        // print_r($response);
        // echo"\n\n\n\n\n\n\n\n";
        // print_r($response->messages[0]->message_status) ;
        


        if( isset( $responseJson->messages[0]->message_status ) )
            {
                canary::listening("WHATSAPP_CNR[$cline] sent notification to client with response.");
                return true ;
            
            }
        else
            {
                canary::listeninge("WHATSAPP_CNR[$cline] sent notification to client with response.");
                return false ;
            }
    }

    public function sendSMS($receiver, $amount , $sender){

    }
    // send Notifications
    public function sendNotificationToReceiver($receiver , $amount , $sender ){

        if (canary::SELECT1("users WHERE `mobile` = '$receiver' OR `username` = '$receiver' OR `email` = '$receiver' "))
        {
            $row = canary::lastSQL();

            if( $row['fcm'] != '0' )
            {

                $deviceToken =  $row['fcm'] ;
                $fsnameSender = explode(' ', trim( $sender ));
                $senderName = $fsnameSender[0].' '.$fsnameSender[1];
                $name =  $row['name'] ;
                $receiverName = explode(' ', trim( $name ))[0];
                $forTest = 'cjgn3pkWRsOmq5MfQfIg-B:APA91bHUZVpO-o8uX8jnCouRfNLP3P3atc-V8-x1Dsk6H1xdz4TkmpkxHpFLDlympZ-fZ9vih02RSfNXr9qay-2jd9ozJWgbAR0Q9zKoGeAQ9oOlxvbfNnKKnsHWuDcJ1SooXbCYv9Lq';
                $deviceToken =  $forTest; 
                $image= 'https://tip.ebznz.com/assets/tip-gift.png';
                if( canary::getLang() == 1  )
                {
                    $title = "Welcome $receiverName";
                    $body = "You get amount $amount from $senderName .";
                }
                else{
                    $title = "مرحبا $receiverName";
                    $body = "لقد تلقيت مبلغ $amount من $senderName .";

                }


                 if( canary::sendFCM($deviceToken, $title , $body , $image))
                 {
                    return ;
                 }
            }

        }


        $forTest = 201557151288 ; // $receiver
        if($this->sendWhatsAppCoinsReceived($forTest, $amount , $sender))
        return ;


        $this->sendSMS($receiver, $amount , $sender) ;
        return ; 

        


    }

    public function sendNotificationToSender($sender , $amount , $type ){

    }



}

?>

<?php
require '../canary/setup.php';
canary::allowedDoctor();
// canary::allowedReport();
import('header-e'); // header , header-e , header-post , header-post-e
import('db');
import('token');// token , tokena for any type
import('geo');
importModel('wallet' , 'driver' , 'Notification');


$request = canary::Request(); // ::GET() , ::POST() , ::REQUEST() for all Method
canary::Maintenance(); // return status code  [426]
canary::Version(1,1,'1.0.0'); // // return status code  [503]
$user = new User();
$wallet = new Wallet();

// $wallet->DoSomething();
// $user->coinsReceived(201557151288 , 950 , 'معز معتصم الحسيني');

// $deviceToken = 'dg8ssYpiT6iSf0BJyst1q4:APA91bEYmUMYGw7Jz1z040cWlxdiBy1Y7dA12u8zepOeGDBfhtYIQIeRiSxuGVoE0YoSMZXxsQZjqqL6c0C0x8UAlNWRE3-lYtqo7R971DXtNFsh4mdZryRwoey4qwWDpcUgQYLjFi3n';
// $deviceTokenFortest = 'cjgn3pkWRsOmq5MfQfIg-B:APA91bHUZVpO-o8uX8jnCouRfNLP3P3atc-V8-x1Dsk6H1xdz4TkmpkxHpFLDlympZ-fZ9vih02RSfNXr9qay-2jd9ozJWgbAR0Q9zKoGeAQ9oOlxvbfNnKKnsHWuDcJ1SooXbCYv9Lq';
$title = 'Hello!';
$body = 'This is a test notification.';
$image= 'https://tip.ebznz.com/assets/tip-gift.png';
// canary::sendFCM($deviceToken, 'Welcome Aymen' , 'You get 75 Coins from Ahmed Saleh aldebrashi .' , $image);
// canary::sendFCM($deviceTokenFortest, 'مرحبا أيمن', 'لقد تلقيت مبلغ 250 قطعة نقدية من أسماء حسن جابر' , $image);

canary::Route('signin' , $user );
canary::Route('signup' , $user );
canary::Route('sendPasswordCode' , $user );
canary::Route('restPassword' , $user );

canary::checkToken('users' , 'token' ); // Almost all APIs under this function require the token.

canary::Route('sendNewOTPCode' , $user );
canary::Route('verifyOTPCode' , $user );
canary::Route('update' , $user );
?>
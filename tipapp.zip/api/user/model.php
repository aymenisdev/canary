<?php

class User extends UserController {

    // Public properties
    public $id;
    public $ide;
    public $name;
    public $username;
    public $mobile;
    public $email;
    public $password;
    public $avatar;
    public $gender;
    public $lang;
    public $birthday;
    public $country;
    public $ip;
    public $token;
    public $fcm;
    public $code;
    public $isAdmin;
    public $isDeleted;
    public $status;
    public $createdAt;
    public $updatedAt;
    public $updatedBy;
    public $lastSeen;

    // Constructor to create a new user object
    public function __construct() {

        return $this;
    }

    // Set user data based on token
    public function set($token) {
        $row = null;

        if (canary::SELECT1("users WHERE `token` = '$token'")) {
            $row = canary::lastSQL();
        }

        if (isset($row)) {
            $this->id = $row['id'];
            $this->ide = $this->encryptID($row['id']);
            $this->name = $row['name'];
            $this->username = $row['username'];
            $this->mobile = $row['mobile'];
            $this->email = $row['email'];
            $this->password = $row['password'];
            $this->avatar = $row['avatar'];
            $this->gender = $row['gender'];
            $this->lang = $row['lang'];
            $this->birthday = $row['birthday'];
            $this->country = $row['country'];
            $this->ip = $row['ip'];
            $this->token = $row['token'];
            $this->fcm = $row['fcm'];
            $this->code = $row['code'];
            $this->isAdmin = $row['isAdmin'];
            $this->isDeleted = $row['isDeleted'];
            $this->status = $row['status'];
            $this->createdAt = $row['createdAt'];
            $this->updatedAt = $row['updatedAt'];
            $this->updatedBy = $row['updatedBy'];
            $this->lastSeen = $row['lastSeen'];
        } else {
            $this->reset();
        }

        return $this->getPublic() ; 
    }

    // Reset user data
    private function reset() {
        $this->id = null;
        $this->ide = null;
        $this->name = null;
        $this->username = null;
        $this->mobile = null;
        $this->email = null;
        $this->password = null;
        $this->avatar = null;
        $this->gender = null;
        $this->lang = null;
        $this->birthday = null;
        $this->country = null;
        $this->ip = null;
        $this->token = null;
        $this->fcm = null;
        $this->code = null;
        $this->isAdmin = null;
        $this->isDeleted = null;
        $this->status = null;
        $this->createdAt = null;
        $this->updatedAt = null;
        $this->updatedBy = null;
        $this->lastSeen = null;
    }

    // Get public user data
    public function getPublic() {
        return [
            'id' => $this->ide,
            'name' => $this->name,
            'username' => $this->username,
            'mobile' => $this->mobile,
            'email' => $this->email,
            'avatar' => $this->avatar,
            'gender' => $this->gender,
            'lang' => $this->lang,
            'birthday' => $this->birthday,
            'country' => $this->country,
            'token' => $this->token,
            'isAdmin' => $this->isAdmin,
            'isDeleted' => $this->isDeleted,
            'status' => $this->status,
            'createdAt' => $this->createdAt,
            'lastSeen' => $this->lastSeen,
        ];
    }

    // Get full user data
    public function get() {
        return [
            'id' => $this->id,
            'ide' => $this->ide,
            'name' => $this->name,
            'username' => $this->username,
            'mobile' => $this->mobile,
            'email' => $this->email,
            'password' => $this->password,
            'avatar' => $this->avatar,
            'gender' => $this->gender,
            'lang' => $this->lang,
            'birthday' => $this->birthday,
            'country' => $this->country,
            'ip' => $this->ip,
            'token' => $this->token,
            'fcm' => $this->fcm,
            'code' => $this->code,
            'onTrip' => $this->onTrip,
            'isActive' => $this->isActive,
            'isAdmin' => $this->isAdmin,
            'isDriver' => $this->isDriver,
            'isDeleted' => $this->isDeleted,
            'status' => $this->status,
            'createdAt' => $this->createdAt,
            'updatedAt' => $this->updatedAt,
            'updatedBy' => $this->updatedBy,
            'lastSeen' => $this->lastSeen,
        ];
    }

}



?>
